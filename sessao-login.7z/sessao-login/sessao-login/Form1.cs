﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sessao_login
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int contador = 0;

        private void btnLogar_Click(object sender, EventArgs e)
        {
            string usuario, senha;
            usuario = txtUsuario.Text;
            senha = txtSenha.Text;
            
            if(usuario=="Vini" && senha=="123")
            {
                home Principal = new home(usuario);
                Principal.Show();
                this.Hide(); //uma vez a sessão fechada a página some
            }
            else
            {
               DialogResult resposta = MessageBox.Show(" usuário ou senha incorretos", "Dados incorretos",
                  MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
               
                if (resposta == DialogResult.Cancel)
                {
                    Application.Exit();
                }
                if (resposta == DialogResult.Retry)
                {
                    contador++;
                    txtUsuario.Clear();
                    txtSenha.Clear();

                    if(contador == 3)
                    {
                        MessageBox.Show("Quantidades de tentativas alcançadas");
                        Application.Exit();
                    }
                }
                    
             }

        }
    }
}
